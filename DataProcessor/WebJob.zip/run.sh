#!/bin/bash
set -e

echo "Job working directory:"
pwd

echo "Looking for manage.py..."
APP_DIR=$(find /tmp -maxdepth 3 -type f -name manage.py 2>/dev/null | grep -v "/tmp/jobs/" | head -n 1 | xargs dirname)

if [ -z "$APP_DIR" ]; then
  echo "Could not find manage.py under /tmp"
  exit 1
fi

echo "Found app directory: $APP_DIR"
cd "$APP_DIR"

if [ -x "$APP_DIR/antenv/bin/python" ]; then
  PYTHON_BIN="$APP_DIR/antenv/bin/python"
elif [ -x "$APP_DIR/antenv/Scripts/python.exe" ]; then
  PYTHON_BIN="$APP_DIR/antenv/Scripts/python.exe"
else
  echo "Could not find virtualenv python in antenv"
  ls -la "$APP_DIR"
  exit 1
fi

echo "Using Python: $PYTHON_BIN"
"$PYTHON_BIN" --version

echo "Starting scheduled trade signal processor..."
"$PYTHON_BIN" manage.py process_daily_signals
echo "Trade signal processor finished."